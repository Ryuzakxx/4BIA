﻿using System.Collections.ObjectModel;

namespace OrdinaFacile
{
    internal class ReceiptWindow
    {
        private ObservableCollection<OrderItem> currentOrder;
        private decimal total;

        public ReceiptWindow(ObservableCollection<OrderItem> currentOrder, decimal total)
        {
            this.currentOrder = currentOrder;
            this.total = total;
        }
    }
}