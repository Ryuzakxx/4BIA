﻿namespace LA_PANINOTECA_D.L.F.M
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            panel1 = new Panel();
            textBox1 = new TextBox();
            button1 = new Button();
            panel2 = new Panel();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            richTextBox1 = new RichTextBox();
            pictureBox1 = new PictureBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            button5 = new Button();
            button6 = new Button();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel1.BackColor = Color.Coral;
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(button1);
            panel1.Location = new Point(1, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1609, 48);
            panel1.TabIndex = 0;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.Coral;
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Font = new Font("Times New Roman", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(81, 8);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(115, 34);
            textBox1.TabIndex = 1;
            textBox1.Text = "MENU";
            // 
            // button1
            // 
            button1.BackColor = Color.Coral;
            button1.BackgroundImageLayout = ImageLayout.None;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(27, 3);
            button1.Name = "button1";
            button1.Size = new Size(59, 42);
            button1.TabIndex = 0;
            button1.Text = "☰";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Coral;
            panel2.Controls.Add(button6);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(button2);
            panel2.Location = new Point(1, 48);
            panel2.Name = "panel2";
            panel2.Size = new Size(223, 779);
            panel2.TabIndex = 2;
            // 
            // button4
            // 
            button4.BackColor = Color.DarkSalmon;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Ravie", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(0, 565);
            button4.Name = "button4";
            button4.Size = new Size(223, 80);
            button4.TabIndex = 2;
            button4.Text = "A SCELTA";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click_1;
            // 
            // button3
            // 
            button3.BackColor = Color.Red;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Bauhaus 93", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(0, 323);
            button3.Name = "button3";
            button3.Size = new Size(223, 79);
            button3.TabIndex = 1;
            button3.Text = "DAIANA BURGER";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click_1;
            // 
            // button2
            // 
            button2.BackColor = Color.DarkSalmon;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Algerian", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(0, 92);
            button2.Name = "button2";
            button2.Size = new Size(223, 80);
            button2.TabIndex = 0;
            button2.Text = "CASA NAPOLI";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // richTextBox1
            // 
            richTextBox1.BackColor = Color.LightGreen;
            richTextBox1.BorderStyle = BorderStyle.None;
            richTextBox1.Font = new Font("Tw Cen MT Condensed", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            richTextBox1.Location = new Point(248, 140);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(460, 574);
            richTextBox1.TabIndex = 3;
            richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.Location = new Point(772, 165);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(649, 546);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.LightGreen;
            textBox2.BorderStyle = BorderStyle.None;
            textBox2.Font = new Font("Showcard Gothic", 21.75F, FontStyle.Italic, GraphicsUnit.Point, 0);
            textBox2.ForeColor = Color.Red;
            textBox2.Location = new Point(772, 721);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(212, 36);
            textBox2.TabIndex = 5;
            textBox2.Text = "CALORIE-->384";
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.LightGreen;
            textBox3.BorderStyle = BorderStyle.None;
            textBox3.Font = new Font("Showcard Gothic", 21.75F, FontStyle.Italic, GraphicsUnit.Point, 0);
            textBox3.ForeColor = Color.Red;
            textBox3.Location = new Point(1015, 721);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(219, 36);
            textBox3.TabIndex = 6;
            textBox3.Text = "PREZZO-->6.80";
            // 
            // button5
            // 
            button5.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            button5.BackColor = Color.PaleGreen;
            button5.FlatAppearance.BorderSize = 10;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Reem Kufi", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.Red;
            button5.Location = new Point(1159, 759);
            button5.Name = "button5";
            button5.Size = new Size(440, 79);
            button5.TabIndex = 11;
            button5.Text = "AGGIUNGI ALL'ORDINE";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.BackColor = Color.Black;
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Lucida Calligraphy", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button6.ForeColor = Color.Gold;
            button6.Location = new Point(0, 702);
            button6.Name = "button6";
            button6.RightToLeft = RightToLeft.No;
            button6.Size = new Size(223, 51);
            button6.TabIndex = 4;
            button6.Text = "🏡 HOME";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGreen;
            ClientSize = new Size(1611, 850);
            Controls.Add(button5);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(pictureBox1);
            Controls.Add(richTextBox1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Form4";
            Text = "Form4";
            Load += Form4_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private TextBox textBox1;
        private Button button1;
        private Panel panel2;
        private Button button4;
        private Button button3;
        private Button button2;
        private RichTextBox richTextBox1;
        private PictureBox pictureBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private Button button5;
        private Button button6;
    }
}