﻿namespace LA_PANINOTECA_D.L.F.M
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            panel1 = new Panel();
            button1 = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            pictureBox1 = new PictureBox();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            panel2 = new Panel();
            button6 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button5 = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel1.BackColor = Color.Coral;
            panel1.BackgroundImageLayout = ImageLayout.None;
            panel1.Controls.Add(button1);
            panel1.Controls.Add(textBox1);
            panel1.ForeColor = Color.Coral;
            panel1.Location = new Point(1, 1);
            panel1.Name = "panel1";
            panel1.Size = new Size(1189, 53);
            panel1.TabIndex = 0;
            // 
            // button1
            // 
            button1.BackColor = Color.Coral;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Black;
            button1.Location = new Point(11, 0);
            button1.Name = "button1";
            button1.Size = new Size(48, 53);
            button1.TabIndex = 1;
            button1.Text = "☰";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.Coral;
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Font = new Font("Algerian", 26.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            textBox1.ForeColor = SystemColors.ButtonFace;
            textBox1.Location = new Point(65, 3);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(246, 47);
            textBox1.TabIndex = 0;
            textBox1.Text = " CASA NAPOLI ";
            textBox1.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.Salmon;
            textBox2.BorderStyle = BorderStyle.None;
            textBox2.Font = new Font("Gill Sans Ultra Bold", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(66, 103);
            textBox2.Name = "textBox2";
            textBox2.RightToLeft = RightToLeft.No;
            textBox2.Size = new Size(501, 20);
            textBox2.TabIndex = 1;
            textBox2.Text = "\"Hai mai assaggiato il vero sapore della passione?\r\n\r\n\r\n\r\n";
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.Salmon;
            textBox3.BorderStyle = BorderStyle.None;
            textBox3.Font = new Font("Gill Sans Ultra Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox3.Location = new Point(66, 145);
            textBox3.Name = "textBox3";
            textBox3.RightToLeft = RightToLeft.No;
            textBox3.Size = new Size(963, 20);
            textBox3.TabIndex = 2;
            textBox3.Text = "Ti presentiamo CASA NAPOLI: il panino che porta il cuore di Napoli direttamente nel tuo piatto!";
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.Salmon;
            textBox4.BorderStyle = BorderStyle.None;
            textBox4.Font = new Font("Gill Sans Ultra Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox4.Location = new Point(66, 187);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(1077, 20);
            textBox4.TabIndex = 3;
            textBox4.Text = "Un'esplosione di gusto che mescola la tradizione e l'innovazione: carne succosa, burrata fresca, guanciale\r\n";
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.Salmon;
            textBox5.BorderStyle = BorderStyle.None;
            textBox5.Font = new Font("Gill Sans Ultra Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox5.Location = new Point(66, 229);
            textBox5.Name = "textBox5";
            textBox5.RightToLeft = RightToLeft.No;
            textBox5.Size = new Size(1095, 20);
            textBox5.TabIndex = 4;
            textBox5.Text = "croccante, pesto di pistacchio e un tocco di maionese al tartufo ... un'esperienza da vivere con tutti i sensi!\"\r\n";
            textBox5.TextChanged += textBox5_TextChanged;
            // 
            // textBox6
            // 
            textBox6.BackColor = Color.Salmon;
            textBox6.BorderStyle = BorderStyle.None;
            textBox6.Font = new Font("Gill Sans Ultra Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox6.Location = new Point(66, 271);
            textBox6.Name = "textBox6";
            textBox6.RightToLeft = RightToLeft.No;
            textBox6.Size = new Size(996, 20);
            textBox6.TabIndex = 5;
            textBox6.Text = "\"Sei pronto a lasciarti travolgere? Vieni a scoprire CASA NAPOLI ... e preparati a perdere la testa!\"";
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.None;
            pictureBox1.Location = new Point(66, 341);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(622, 354);
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // textBox7
            // 
            textBox7.BackColor = Color.Salmon;
            textBox7.BorderStyle = BorderStyle.None;
            textBox7.Font = new Font("Showcard Gothic", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            textBox7.ForeColor = Color.White;
            textBox7.Location = new Point(750, 419);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(191, 30);
            textBox7.TabIndex = 7;
            textBox7.Text = " CALORIE-->950  ";
            // 
            // textBox8
            // 
            textBox8.BackColor = Color.Salmon;
            textBox8.BorderStyle = BorderStyle.None;
            textBox8.Font = new Font("Showcard Gothic", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            textBox8.ForeColor = Color.White;
            textBox8.Location = new Point(750, 455);
            textBox8.Name = "textBox8";
            textBox8.RightToLeft = RightToLeft.No;
            textBox8.Size = new Size(212, 30);
            textBox8.TabIndex = 8;
            textBox8.Text = "PREZZO--> 12.50";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Coral;
            panel2.Controls.Add(button6);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(button2);
            panel2.Location = new Point(1, 52);
            panel2.Name = "panel2";
            panel2.Size = new Size(223, 765);
            panel2.TabIndex = 9;
            // 
            // button6
            // 
            button6.BackColor = Color.Black;
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Lucida Calligraphy", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button6.ForeColor = Color.Gold;
            button6.Location = new Point(0, 702);
            button6.Name = "button6";
            button6.RightToLeft = RightToLeft.No;
            button6.Size = new Size(223, 51);
            button6.TabIndex = 3;
            button6.Text = "🏡 HOME";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.DarkSalmon;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Bauhaus 93", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(0, 289);
            button4.Name = "button4";
            button4.Size = new Size(223, 83);
            button4.TabIndex = 2;
            button4.Text = "DAIANA BURGER ";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.DarkSalmon;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Stencil", 24F, FontStyle.Italic, GraphicsUnit.Point, 0);
            button3.Location = new Point(0, 546);
            button3.Name = "button3";
            button3.Size = new Size(223, 83);
            button3.TabIndex = 1;
            button3.Text = "A SCELTA";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Red;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Algerian", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(3, 77);
            button2.Name = "button2";
            button2.Size = new Size(220, 83);
            button2.TabIndex = 0;
            button2.Text = "CASA NAPOLI";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button5
            // 
            button5.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            button5.FlatAppearance.BorderSize = 10;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Reem Kufi", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.FromArgb(128, 255, 128);
            button5.Location = new Point(750, 703);
            button5.Name = "button5";
            button5.Size = new Size(440, 79);
            button5.TabIndex = 10;
            button5.Text = "AGGIUNGI ALL'ORDINE";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Salmon;
            ClientSize = new Size(1196, 817);
            Controls.Add(button5);
            Controls.Add(panel2);
            Controls.Add(textBox8);
            Controls.Add(textBox7);
            Controls.Add(pictureBox1);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(panel1);
            Name = "Form3";
            RightToLeft = RightToLeft.Yes;
            Text = "Form3";
            Load += Form3_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private PictureBox pictureBox1;
        private TextBox textBox7;
        private TextBox textBox8;
        private Button button1;
        private Panel panel2;
        private Button button3;
        private Button button2;
        private Button button4;
        private Button button5;
        private Button button6;
    }
}