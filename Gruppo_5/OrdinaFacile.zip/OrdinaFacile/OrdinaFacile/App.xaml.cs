﻿// 
// File: App.xaml.cs
// Descrizione: Code-behind per App.xaml. In questo esempio non è necessaria logica aggiuntiva.
// 
using System.Windows;

namespace OrdinaFacile
{
    /// <summary>
    /// Logica di interazione per App.xaml
    /// </summary>
    public partial class App : Application
    {
        // Eventuali inizializzazioni globali possono essere inserite qui.
    }
}
