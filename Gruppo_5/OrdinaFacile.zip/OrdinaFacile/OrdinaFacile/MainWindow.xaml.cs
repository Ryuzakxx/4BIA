﻿// ==========================================================
// USING: Importiamo i namespace necessari per utilizzare le funzionalità di C# e WPF.
// Ogni "using" rende disponibili classi e metodi per gestire collezioni, eventi, interfacce grafiche, ecc.
// ==========================================================
using System;                                // Fornisce tipi di base e funzionalità di sistema.
using System.Collections.ObjectModel;        // Per ObservableCollection, che notifica automaticamente la UI quando viene modificata.
using System.ComponentModel;                   // Per INotifyPropertyChanged, che permette al binding di aggiornarsi quando le proprietà cambiano.
using System.Globalization;                    // Per gestire la formattazione di numeri e valute.
using System.Linq;                             // Per utilizzare LINQ e operazioni su collezioni.
using System.Text;                             // Per utilizzare StringBuilder, utile per costruire stringhe dinamicamente.
using System.Windows;                          // Per utilizzare le classi base di WPF (Window, MessageBox, ecc.).
using System.Windows.Controls;                 // Per utilizzare i controlli UI come Button, ListBox, ComboBox, ecc.
using System.Windows.Documents;                // Per utilizzare FlowDocument, utile per la stampa dei documenti.

namespace OrdinaFacile
{
    // ==========================================================
    // La classe MainWindow rappresenta la finestra principale dell'applicazione.
    // In WPF, la logica dell'interfaccia utente (UI) viene gestita in un file "code-behind".
    // La classe implementa INotifyPropertyChanged per notificare alla UI ogni cambiamento di proprietà.
    // ==========================================================
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        // ==========================================================
        // SEZIONE: Proprietà per il TAB "CAMERIERE"
        // ==========================================================

        // Dichiarazione della proprietà "Tavoli" di tipo ObservableCollection<Tavolo>.
        // Ogni elemento in questa collezione rappresenta un tavolo nel ristorante.
        public ObservableCollection<Tavolo> Tavoli { get; set; }

        // Dichiarazione della proprietà "ProdottiMenu" di tipo ObservableCollection<ProdottoMenu>.
        // Ogni elemento rappresenta un prodotto del menu. Ogni prodotto ha un "Id" che lo identifica in modo univoco.
        public ObservableCollection<ProdottoMenu> ProdottiMenu { get; set; }

        // Dichiarazione della proprietà "Categorie" di tipo ObservableCollection<string>.
        // Questa collezione contiene le categorie (es. "TAPAS", "TACOS", ecc.) utilizzate per filtrare i prodotti.
        public ObservableCollection<string> Categorie { get; set; }

        // ==========================================================
        // SEZIONE: Proprietà per il TAB "CLIENTE"
        // ==========================================================

        // Dichiarazione della proprietà "Prodotti" di tipo ObservableCollection<ProdottoMenu>.
        // Questa è una copia della lista dei prodotti del menu, per il tab Cliente, per poter modificare le quantità senza alterare l'originale.
        public ObservableCollection<ProdottoMenu> Prodotti { get; set; }

        // Dichiarazione della proprietà "Carrello" di tipo ObservableCollection<OrdineCliente>.
        // Questa collezione rappresenta gli ordini (prodotti con quantità) selezionati dal cliente.
        public ObservableCollection<OrdineCliente> Carrello { get; set; }

        // ==========================================================
        // COSTRUTTORE: Viene eseguito all'apertura della finestra.
        // ==========================================================
        public MainWindow()
        {
            // Inizializza i componenti definiti nel file XAML (layout e controlli).
            InitializeComponent();

            // Metodo personalizzato per inizializzare tutte le collezioni e i dati necessari all'applicazione.
            InitializeData();

            // Imposta il DataContext della finestra a "this".
            // Questo consente di collegare (data binding) le proprietà pubbliche di questa classe ai controlli definiti in XAML.
            DataContext = this;
        }

        // ==========================================================
        // INotifyPropertyChanged: Meccanismo per notificare alla UI che una proprietà è cambiata.
        // ==========================================================
        public event PropertyChangedEventHandler PropertyChanged;

        // Metodo helper per invocare l'evento PropertyChanged.
        // Utilizza l'operatore "=>" per definire una funzione in modo conciso.
        private void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

        // ==========================================================
        // Metodo InitializeData: Inizializza tutte le collezioni e i dati dell'applicazione.
        // ==========================================================
        private void InitializeData()
        {
            // --- Inizializzazione dei tavoli ---
            // Creiamo 5 tavoli numerati da 1 a 5.
            // Enumerable.Range(1, 5) genera numeri da 1 a 5; per ogni numero creiamo una nuova istanza di Tavolo.
            Tavoli = new ObservableCollection<Tavolo>(
                Enumerable.Range(1, 5).Select(i => new Tavolo(i))
            );
            // Associa la collezione Tavoli al controllo ListBox "LbTavoli" definito in XAML.
            LbTavoli.ItemsSource = Tavoli;

            // --- Inizializzazione delle categorie ---
            // Creiamo una collezione di stringhe contenente le categorie.
            Categorie = new ObservableCollection<string>
            {
                "TAPAS", "TACOS", "AREPAS", "BURGERS", "BURRITOS",
                "BIRRE ALLA SPINA", "BIRRE IN BOTTIGLIA", "BEVANDE ANALCOLICHE"
            };
            // Associa la collezione Categorie al ComboBox "CbCategorie".
            CbCategorie.ItemsSource = Categorie;
            // Seleziona la prima categoria per default.
            CbCategorie.SelectedIndex = 0;

            // --- Inizializzazione del menu dei prodotti ---
            // Usiamo il tipo "decimal" per il prezzo, perché è ideale per valori monetari grazie alla sua elevata precisione,
            // evitando errori di arrotondamento tipici di float o double.
            ProdottiMenu = new ObservableCollection<ProdottoMenu>
            {
                // *** Categoria TAPAS (ID 1-20) ***
                new ProdottoMenu { Id = 1,  Nome = "Polpo Glassato",                   Categoria = "TAPAS",           Prezzo = 10.00m },
                new ProdottoMenu { Id = 2,  Nome = "Empanadas di Verdure",               Categoria = "TAPAS",           Prezzo = 8.00m },
                new ProdottoMenu { Id = 3,  Nome = "Empanadas di Pollo",                 Categoria = "TAPAS",           Prezzo = 8.00m },
                new ProdottoMenu { Id = 4,  Nome = "Empanadas di Manzo",                 Categoria = "TAPAS",           Prezzo = 8.00m },
                new ProdottoMenu { Id = 5,  Nome = "Polpo Fritto",                       Categoria = "TAPAS",           Prezzo = 5.00m },
                new ProdottoMenu { Id = 6,  Nome = "Papas Bravas",                       Categoria = "TAPAS",           Prezzo = 6.00m },
                new ProdottoMenu { Id = 7,  Nome = "Sopa",                               Categoria = "TAPAS",           Prezzo = 6.00m },
                new ProdottoMenu { Id = 8,  Nome = "Ceviche di Pescato",                 Categoria = "TAPAS",           Prezzo = 10.00m },
                new ProdottoMenu { Id = 9,  Nome = "Patacones",                          Categoria = "TAPAS",           Prezzo = 6.00m },
                new ProdottoMenu { Id = 10, Nome = "Churros di Patate",                  Categoria = "TAPAS",           Prezzo = 6.00m },
                new ProdottoMenu { Id = 11, Nome = "Yuca",                               Categoria = "TAPAS",           Prezzo = 6.00m },
                new ProdottoMenu { Id = 12, Nome = "Ceviche di Chicharrones",            Categoria = "TAPAS",           Prezzo = 8.00m },
                new ProdottoMenu { Id = 13, Nome = "Ceviche di Mango",                   Categoria = "TAPAS",           Prezzo = 6.00m },
                new ProdottoMenu { Id = 14, Nome = "Tris Fritto",                        Categoria = "TAPAS",           Prezzo = 8.00m },
                new ProdottoMenu { Id = 15, Nome = "Polpette di Manzo",                  Categoria = "TAPAS",           Prezzo = 5.00m },
                new ProdottoMenu { Id = 16, Nome = "Polpette di Verdure",                Categoria = "TAPAS",           Prezzo = 5.00m },
                new ProdottoMenu { Id = 17, Nome = "Costine di Maiale",                  Categoria = "TAPAS",           Prezzo = 8.00m },
                new ProdottoMenu { Id = 18, Nome = "Papas Creole",                       Categoria = "TAPAS",           Prezzo = 6.00m },
                new ProdottoMenu { Id = 19, Nome = "Entraña (Diaframma di Manzo Podolico 200g)", Categoria = "TAPAS",    Prezzo = 15.00m },
                new ProdottoMenu { Id = 20, Nome = "Hummus di Ceci",                     Categoria = "TAPAS",           Prezzo = 8.00m },

                // *** Categoria TACOS (ID 21-24) ***
                new ProdottoMenu { Id = 21, Nome = "Il Ruspante",                       Categoria = "TACOS",           Prezzo = 5.00m },
                new ProdottoMenu { Id = 22, Nome = "Lo Sfilacciato",                     Categoria = "TACOS",           Prezzo = 5.00m },
                new ProdottoMenu { Id = 23, Nome = "Il Fresco",                          Categoria = "TACOS",           Prezzo = 5.00m },
                new ProdottoMenu { Id = 24, Nome = "Lo Stagionale",                      Categoria = "TACOS",           Prezzo = 5.00m },

                // *** Categoria AREPAS (ID 25-27) ***
                new ProdottoMenu { Id = 25, Nome = "Arepa Ripiena di Manzo",             Categoria = "AREPAS",          Prezzo = 5.00m },
                new ProdottoMenu { Id = 26, Nome = "Arepa Ripiena di Verdure",           Categoria = "AREPAS",          Prezzo = 5.00m },
                new ProdottoMenu { Id = 27, Nome = "Arepa Ripiena di Salumi e Formaggi",  Categoria = "AREPAS",          Prezzo = 5.00m },

                // *** Categoria BURGERS (ID 28-30) ***
                new ProdottoMenu { Id = 28, Nome = "Manzo (220g)",                       Categoria = "BURGERS",         Prezzo = 12.00m },
                new ProdottoMenu { Id = 29, Nome = "Pollo (180g)",                       Categoria = "BURGERS",         Prezzo = 12.00m },
                new ProdottoMenu { Id = 30, Nome = "Vegetariano (150g)",                 Categoria = "BURGERS",         Prezzo = 12.00m },

                // *** Categoria BURRITOS (ID 31-33) ***
                new ProdottoMenu { Id = 31, Nome = "Pollo",                            Categoria = "BURRITOS",        Prezzo = 8.00m },
                new ProdottoMenu { Id = 32, Nome = "Vegetariano",                      Categoria = "BURRITOS",        Prezzo = 8.00m },
                new ProdottoMenu { Id = 33, Nome = "Manzo",                            Categoria = "BURRITOS",        Prezzo = 8.00m },

                // *** Categoria BIRRE ALLA SPINA (ID 34-43) ***
                new ProdottoMenu { Id = 34, Nome = "Stella Artois - Piccola (0,20cl)",   Categoria = "BIRRE ALLA SPINA", Prezzo = 3.00m },
                new ProdottoMenu { Id = 35, Nome = "Stella Artois - Media (0,40cl)",       Categoria = "BIRRE ALLA SPINA", Prezzo = 5.00m },
                new ProdottoMenu { Id = 36, Nome = "Stella Artois - Mezza pinta",          Categoria = "BIRRE ALLA SPINA", Prezzo = 6.00m },
                new ProdottoMenu { Id = 37, Nome = "Leffe Blonde - Piccola (0,20cl)",      Categoria = "BIRRE ALLA SPINA", Prezzo = 3.00m },
                new ProdottoMenu { Id = 38, Nome = "Leffe Blonde - Media (0,40cl)",          Categoria = "BIRRE ALLA SPINA", Prezzo = 5.00m },
                new ProdottoMenu { Id = 39, Nome = "Leffe Blonde - Mezza pinta",             Categoria = "BIRRE ALLA SPINA", Prezzo = 6.00m },
                new ProdottoMenu { Id = 40, Nome = "Bayreuther Brauhaus - Piccola (0,20cl)",   Categoria = "BIRRE ALLA SPINA", Prezzo = 3.50m },
                new ProdottoMenu { Id = 41, Nome = "Bayreuther Brauhaus - Media (0,40cl)",       Categoria = "BIRRE ALLA SPINA", Prezzo = 6.00m },
                new ProdottoMenu { Id = 42, Nome = "Hoegarden - Piccola (0,25cl)",            Categoria = "BIRRE ALLA SPINA", Prezzo = 3.50m },
                new ProdottoMenu { Id = 43, Nome = "Hoegarden - Media (0,50cl)",              Categoria = "BIRRE ALLA SPINA", Prezzo = 5.50m },

                // *** Categoria BIRRE IN BOTTIGLIA (ID 44-51) ***
                new ProdottoMenu { Id = 44, Nome = "Peroni / Nastro Azzurro",            Categoria = "BIRRE IN BOTTIGLIA", Prezzo = 2.50m },
                new ProdottoMenu { Id = 45, Nome = "DAB",                               Categoria = "BIRRE IN BOTTIGLIA", Prezzo = 2.50m },
                new ProdottoMenu { Id = 46, Nome = "Peroni Capri",                      Categoria = "BIRRE IN BOTTIGLIA", Prezzo = 3.00m },
                new ProdottoMenu { Id = 47, Nome = "Delirium",                          Categoria = "BIRRE IN BOTTIGLIA", Prezzo = 5.00m },
                new ProdottoMenu { Id = 48, Nome = "Estrella",                          Categoria = "BIRRE IN BOTTIGLIA", Prezzo = 2.50m },
                new ProdottoMenu { Id = 49, Nome = "Corona",                            Categoria = "BIRRE IN BOTTIGLIA", Prezzo = 4.00m },
                new ProdottoMenu { Id = 50, Nome = "Raffo Grezza",                      Categoria = "BIRRE IN BOTTIGLIA", Prezzo = 2.50m },
                new ProdottoMenu { Id = 51, Nome = "Raffo Original",                    Categoria = "BIRRE IN BOTTIGLIA", Prezzo = 2.50m },

                // *** Categoria BEVANDE ANALCOLICHE (ID 52-68) ***
                new ProdottoMenu { Id = 52, Nome = "Acqua 0,5 L Naturale",              Categoria = "BEVANDE ANALCOLICHE", Prezzo = 2.50m },
                new ProdottoMenu { Id = 53, Nome = "Acqua 0,5 L Frizzante",              Categoria = "BEVANDE ANALCOLICHE", Prezzo = 2.50m },
                new ProdottoMenu { Id = 54, Nome = "Acqua 1 L Naturale",                Categoria = "BEVANDE ANALCOLICHE", Prezzo = 3.00m },
                new ProdottoMenu { Id = 55, Nome = "Acqua 1 L Frizzante",               Categoria = "BEVANDE ANALCOLICHE", Prezzo = 3.00m },
                new ProdottoMenu { Id = 56, Nome = "Fanta",                             Categoria = "BEVANDE ANALCOLICHE", Prezzo = 3.00m },
                new ProdottoMenu { Id = 57, Nome = "Coca Cola",                         Categoria = "BEVANDE ANALCOLICHE", Prezzo = 3.00m },
                new ProdottoMenu { Id = 58, Nome = "Coca Cola Zero",                    Categoria = "BEVANDE ANALCOLICHE", Prezzo = 3.00m },
                new ProdottoMenu { Id = 59, Nome = "Lemon Soda",                        Categoria = "BEVANDE ANALCOLICHE", Prezzo = 3.00m },
                new ProdottoMenu { Id = 60, Nome = "Chinotto Lauretana",                Categoria = "BEVANDE ANALCOLICHE", Prezzo = 3.50m },
                new ProdottoMenu { Id = 61, Nome = "Limonata Lauretana",                Categoria = "BEVANDE ANALCOLICHE", Prezzo = 3.50m },
                new ProdottoMenu { Id = 62, Nome = "Aranciata Lauretana",               Categoria = "BEVANDE ANALCOLICHE", Prezzo = 3.50m },
                new ProdottoMenu { Id = 63, Nome = "Acqua Tonica Kinley",               Categoria = "BEVANDE ANALCOLICHE", Prezzo = 3.50m },
                new ProdottoMenu { Id = 64, Nome = "Ginger Beer",                       Categoria = "BEVANDE ANALCOLICHE", Prezzo = 3.50m },
                new ProdottoMenu { Id = 65, Nome = "Soda Pompelmo Rosa",                Categoria = "BEVANDE ANALCOLICHE", Prezzo = 3.50m },
                new ProdottoMenu { Id = 66, Nome = "Estathé alla Pesca",                Categoria = "BEVANDE ANALCOLICHE", Prezzo = 2.50m },
                new ProdottoMenu { Id = 67, Nome = "Estathé al Limone",                 Categoria = "BEVANDE ANALCOLICHE", Prezzo = 2.50m },
                new ProdottoMenu { Id = 68, Nome = "Estratto di Frutta",                Categoria = "BEVANDE ANALCOLICHE", Prezzo = 4.00m }
            };

            // Aggiorna il ComboBox dei prodotti in base alla categoria selezionata (inizialmente la prima).
            AggiornaProdotti(CbCategorie.SelectedItem as string);

            // --- Inizializzazione per il tab "CLIENTE" ---
            // Creiamo una copia della lista dei prodotti per il tab Cliente.
            Prodotti = new ObservableCollection<ProdottoMenu>(ProdottiMenu);

            // Inizializza il ComboBox "CbQuantita" per selezionare una quantità (da 1 a 20).
            for (int i = 1; i <= 20; i++)
                CbQuantita.Items.Add(i);
            CbQuantita.SelectedIndex = 0; // Seleziona per default la quantità 1.

            // Inizializza il carrello del cliente (lista degli ordini selezionati).
            Carrello = new ObservableCollection<OrdineCliente>();
            LstCarrello.ItemsSource = Carrello;
        }

        // ==========================================================
        // Metodo AggiornaProdotti: Filtra e visualizza i prodotti in base alla categoria selezionata.
        // ==========================================================
        private void AggiornaProdotti(string categoria)
        {
            // Verifica se la lista dei prodotti è nulla o se la categoria è una stringa vuota.
            if (ProdottiMenu == null || string.IsNullOrEmpty(categoria))
            {
                // Se vero, imposta la sorgente dati del ComboBox dei prodotti a null.
                CbProdotti.ItemsSource = null;
                return;
            }
            // Utilizziamo LINQ per ottenere una lista dei prodotti che appartengono alla categoria selezionata.
            var prodottiFiltrati = ProdottiMenu.Where(p => p.Categoria == categoria).ToList();
            // Imposta la sorgente dati del ComboBox "CbProdotti" con la lista filtrata.
            CbProdotti.ItemsSource = prodottiFiltrati;
            // Specifica che il ComboBox deve mostrare la proprietà "Nome" di ogni prodotto.
            CbProdotti.DisplayMemberPath = "Nome";
            // Se la lista filtrata contiene elementi, seleziona il primo; altrimenti, nessun elemento viene selezionato.
            CbProdotti.SelectedIndex = prodottiFiltrati.Any() ? 0 : -1;
        }

        // ==========================================================
        // EVENT HANDLERS per il TAB "CAMERIERE"
        // ==========================================================

        // Questo metodo viene chiamato quando l'utente seleziona un tavolo dalla ListBox "LbTavoli".
        private void LbTavoliSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Prova a convertire l'elemento selezionato in un oggetto di tipo Tavolo.
            var tavolo = LbTavoli.SelectedItem as Tavolo;
            if (tavolo != null)
            {
                // Se è stato selezionato un tavolo, aggiorna il TextBlock "TbTavoloSelezionato" per mostrare il numero del tavolo.
                TbTavoloSelezionato.Text = $"Tavolo {tavolo.NumeroTavolo}";
                // Collega la DataGrid "DgOrdini" alla lista degli ordini di questo tavolo.
                DgOrdini.ItemsSource = tavolo.Ordini;
                // Imposta il DataContext del CheckBox "CbStato" per abilitare il data binding con la proprietà "Occupato" del tavolo.
                CbStato.DataContext = tavolo;
            }
            else
            {
                // Se nessun tavolo è selezionato, imposta i controlli a null o a valori predefiniti.
                TbTavoloSelezionato.Text = "Seleziona un tavolo";
                DgOrdini.ItemsSource = null;
                CbStato.DataContext = null;
            }
        }

        // Questo metodo viene chiamato quando la categoria nel ComboBox "CbCategorie" cambia.
        // Usa una espressione lambda per chiamare il metodo AggiornaProdotti.
        private void CbCategorie_SelectionChanged(object sender, SelectionChangedEventArgs e) =>
            AggiornaProdotti(CbCategorie.SelectedItem as string);

        // Questo metodo viene chiamato quando l'utente seleziona un prodotto nel ComboBox "CbProdotti".
        // Mostra il prezzo del prodotto selezionato nel TextBox "TbPrezzo".
        private void CbProdotti_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CbProdotti.SelectedItem is ProdottoMenu p)
                TbPrezzo.Text = p.Prezzo.ToString("F2", CultureInfo.CurrentCulture);
        }

        // Questo metodo aggiunge un nuovo ordine al tavolo selezionato.
        private void AggiungiOrdine_Click(object sender, RoutedEventArgs e)
        {
            // Prova a ottenere il tavolo selezionato dalla ListBox.
            var tavolo = LbTavoli.SelectedItem as Tavolo;
            if (tavolo == null)
            {
                // Se nessun tavolo è selezionato, mostra un messaggio all'utente.
                MessageBox.Show("Seleziona un tavolo!");
                return;
            }
            // Verifica se un prodotto è selezionato e se è stata scelta una quantità.
            if (!(CbProdotti.SelectedItem is ProdottoMenu prodotto) || CbQuantita.SelectedItem == null)
            {
                MessageBox.Show("Seleziona un prodotto e una quantità!");
                return;
            }
            // Prova a convertire il testo del prezzo (stringa) in un valore decimal.
            if (!decimal.TryParse(TbPrezzo.Text, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal prezzo))
            {
                MessageBox.Show("Prezzo non valido!");
                return;
            }
            // Imposta il tavolo come occupato e aggiunge un nuovo ordine alla lista degli ordini del tavolo.
            tavolo.Occupato = true;
            tavolo.Ordini.Add(new Ordine
            {
                Nome = prodotto.Nome,
                Quantità = (int)CbQuantita.SelectedItem,
                Prezzo = prezzo
            });
            // Resetta la selezione della quantità al valore 1.
            CbQuantita.SelectedIndex = 0;
        }

        // Questo metodo rimuove l'ordine selezionato dalla DataGrid "DgOrdini".
        private void RimuoviOrdine_Click(object sender, RoutedEventArgs e)
        {
            var tavolo = LbTavoli.SelectedItem as Tavolo;
            if (tavolo == null || DgOrdini.SelectedItem == null)
            {
                MessageBox.Show("Seleziona un ordine!");
                return;
            }
            // Chiede conferma all'utente prima di rimuovere l'ordine.
            if (MessageBox.Show("Rimuovere l'ordine?", "Conferma", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                tavolo.Ordini.Remove((Ordine)DgOrdini.SelectedItem);
        }

        // Questo metodo libera tutti i tavoli, impostando lo stato "Occupato" a false.
        // Quando un tavolo diventa libero, la sua lista degli ordini viene cancellata.
        private void LiberaTutti_Click(object sender, RoutedEventArgs e)
        {
            foreach (var tavolo in Tavoli)
                tavolo.Occupato = false;
        }

        // Questo metodo aggiunge un nuovo tavolo, assegnando il numero disponibile successivo.
        private void AggiungiTavolo_Click(object sender, RoutedEventArgs e)
        {
            int nuovoNumero = 1;
            // Ottiene tutti i numeri dei tavoli già esistenti e li ordina in modo crescente.
            var numeriUsati = Tavoli.Select(t => t.NumeroTavolo).OrderBy(n => n).ToList();
            // Incrementa "nuovoNumero" finché trova un numero già usato.
            foreach (var n in numeriUsati)
            {
                if (n == nuovoNumero)
                    nuovoNumero++;
                else
                    break;
            }
            // Aggiunge un nuovo tavolo con il numero disponibile.
            Tavoli.Add(new Tavolo(nuovoNumero));
        }

        // Questo metodo rimuove il tavolo selezionato dopo aver chiesto conferma all'utente.
        private void RimuoviTavolo_Click(object sender, RoutedEventArgs e)
        {
            var tavolo = LbTavoli.SelectedItem as Tavolo;
            if (tavolo != null && MessageBox.Show($"Rimuovere {tavolo}?", "Conferma", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                Tavoli.Remove(tavolo);
        }

        // Questo metodo stampa la comanda (riepilogo degli ordini) del tavolo selezionato.
        private void StampaComandaTavolo_Click(object sender, RoutedEventArgs e)
        {
            var tavolo = LbTavoli.SelectedItem as Tavolo;
            if (tavolo == null || !tavolo.Ordini.Any())
            {
                MessageBox.Show("Nessun ordine da stampare!");
                return;
            }
            // Costruisce la stringa della comanda usando StringBuilder.
            StringBuilder comanda = new StringBuilder();
            comanda.AppendLine($"COMANDA TAVOLO {tavolo.NumeroTavolo}");
            comanda.AppendLine("================================");
            foreach (var ordine in tavolo.Ordini)
                comanda.AppendLine($"{ordine.Nome} x{ordine.Quantità} - {(ordine.Prezzo * ordine.Quantità):C}");
            comanda.AppendLine("================================");
            comanda.AppendLine($"TOTALE: {tavolo.Ordini.Sum(o => o.Prezzo * o.Quantità):C}");
            // Avvia il processo di stampa passando la stringa della comanda.
            StampaComanda(comanda.ToString());
        }

        // Questo metodo stampa le comande di tutti i tavoli.
        private void StampaTutto_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder comandeTotali = new StringBuilder();
            // Ordina i tavoli in base al loro numero e itera su ciascuno.
            foreach (var tavolo in Tavoli.OrderBy(t => t.NumeroTavolo))
            {
                if (tavolo.Ordini.Any())
                {
                    comandeTotali.AppendLine($"COMANDA TAVOLO {tavolo.NumeroTavolo}");
                    comandeTotali.AppendLine("================================");
                    foreach (var ordine in tavolo.Ordini)
                        comandeTotali.AppendLine($"{ordine.Nome} x{ordine.Quantità} - {(ordine.Prezzo * ordine.Quantità):C}");
                    comandeTotali.AppendLine("================================");
                    comandeTotali.AppendLine($"TOTALE: {tavolo.Ordini.Sum(o => o.Prezzo * o.Quantità):C}");
                    comandeTotali.AppendLine();
                }
            }
            // Se non ci sono ordini, mostra un messaggio.
            if (comandeTotali.Length == 0)
            {
                MessageBox.Show("Nessun ordine da stampare!");
                return;
            }
            StampaComanda(comandeTotali.ToString());
        }

        // Questo metodo gestisce la stampa di un documento contenente il riepilogo degli ordini.
        private void StampaComanda(string testo)
        {
            PrintDialog printDialog = new PrintDialog();
            // Mostra il dialogo di stampa; se l'utente conferma...
            if (printDialog.ShowDialog() == true)
            {
                // Crea un documento formattato con FlowDocument contenente il testo passato.
                FlowDocument doc = new FlowDocument(new Paragraph(new Run(testo)))
                {
                    PageWidth = printDialog.PrintableAreaWidth,
                    PageHeight = printDialog.PrintableAreaHeight,
                    ColumnWidth = printDialog.PrintableAreaWidth
                };
                // Avvia il processo di stampa.
                printDialog.PrintDocument(((IDocumentPaginatorSource)doc).DocumentPaginator, "Comanda Tavolo");
            }
        }

        // Questo metodo viene chiamato quando la selezione nella DataGrid degli ordini cambia.
        // Attualmente non contiene logica, ma può essere usato per ulteriori funzionalità in futuro.
        private void DgOrdini_SelectionChanged(object sender, SelectionChangedEventArgs e) { }

        // ==========================================================
        // EVENT HANDLERS per il TAB "CLIENTE"
        // ==========================================================

        // Questo metodo viene chiamato quando l'utente seleziona una categoria nella ListBox "LstCategorieCliente".
        // Esegue un'operazione condizionale (ternaria) per aggiornare la sorgente dati degli ItemsControl.
        private void LstCategorieCliente_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // "string cat = LstCategorieCliente.SelectedItem as string;" prova a convertire l'elemento selezionato in una stringa.
            string cat = LstCategorieCliente.SelectedItem as string;

            // La seguente istruzione usa l'operatore ternario:
            // Se "cat" è una stringa vuota o null (string.IsNullOrEmpty(cat) restituisce true), allora ItemsProdotti.ItemsSource viene impostato a null.
            // Altrimenti, ItemsProdotti.ItemsSource viene impostato alla lista dei prodotti filtrata per la categoria "cat".
            ItemsProdotti.ItemsSource = string.IsNullOrEmpty(cat)
                ? null
                : ProdottiMenu.Where(p => p.Categoria == cat).ToList();
        }

        // Questo metodo gestisce il click sul pulsante "-" per diminuire la quantità selezionata di un prodotto nel tab Cliente.
        private void RimuoviOrdineCliente_Click(object sender, RoutedEventArgs e)
        {
            // Verifica che il pulsante (Button) abbia un Tag e che questo Tag possa essere convertito in un intero (prodId).
            if (sender is Button btn && btn.Tag != null && int.TryParse(btn.Tag.ToString(), out int prodId))
            {
                // Cerca il prodotto corrispondente in ProdottiMenu in base all'ID.
                var prodotto = ProdottiMenu.FirstOrDefault(p => p.Id == prodId);
                if (prodotto != null && prodotto.QuantitaSelezionata > 0)
                {
                    // Decrementa la quantità selezionata.
                    prodotto.QuantitaSelezionata--;
                    // Cerca se il prodotto è già presente nel carrello.
                    var ordine = Carrello.FirstOrDefault(o => o.Prodotto.Id == prodId);
                    if (ordine != null)
                    {
                        // Se la quantità raggiunge 0, rimuove l'articolo dal carrello.
                        if (prodotto.QuantitaSelezionata == 0)
                            Carrello.Remove(ordine);
                        else
                            ordine.Quantita = prodotto.QuantitaSelezionata;
                    }
                    // Aggiorna il totale del carrello.
                    AggiornaTotale();
                }
            }
        }

        // Questo metodo gestisce il click sul pulsante "+" per aumentare la quantità selezionata di un prodotto nel tab Cliente.
        private void AggiungiOrdineCliente_Click(object sender, RoutedEventArgs e)
        {
            // Verifica che il pulsante abbia un Tag valido e lo converte in intero (prodId).
            if (sender is Button btn && btn.Tag != null && int.TryParse(btn.Tag.ToString(), out int prodId))
            {
                // Cerca il prodotto corrispondente in ProdottiMenu.
                var prodotto = ProdottiMenu.FirstOrDefault(p => p.Id == prodId);
                if (prodotto != null)
                {
                    // Incrementa la quantità selezionata per il prodotto.
                    prodotto.QuantitaSelezionata++;
                    // Cerca se il prodotto è già presente nel carrello.
                    var ordine = Carrello.FirstOrDefault(o => o.Prodotto.Id == prodId);
                    if (ordine != null)
                        // Se già presente, aggiorna la quantità.
                        ordine.Quantita = prodotto.QuantitaSelezionata;
                    else
                        // Altrimenti, aggiunge il prodotto come nuovo ordine nel carrello.
                        Carrello.Add(new OrdineCliente { Prodotto = prodotto, Quantita = prodotto.QuantitaSelezionata });
                    // Aggiorna il totale del carrello.
                    AggiornaTotale();
                }
            }
        }

        // Questo metodo viene chiamato quando l'utente clicca sul pulsante "Invia Ordine" nel tab Cliente.
        private void InviaOrdineCliente_Click(object sender, RoutedEventArgs e)
        {
            // Verifica che l'utente abbia selezionato un tavolo dal ComboBox "CbTavoliCliente".
            if (CbTavoliCliente.SelectedItem is Tavolo tavolo)
            {
                // Se il carrello è vuoto, mostra un messaggio e interrompe l'operazione.
                if (!Carrello.Any())
                {
                    MessageBox.Show("Il carrello è vuoto.");
                    return;
                }
                // Per ogni articolo nel carrello, aggiunge un nuovo ordine al tavolo.
                foreach (var ordine in Carrello)
                    tavolo.Ordini.Add(new Ordine { Nome = ordine.Prodotto.Nome, Quantità = ordine.Quantita, Prezzo = ordine.Prodotto.Prezzo });

                // Costruisce un riepilogo dell'ordine per mostrare all'utente.
                StringBuilder riepilogo = new StringBuilder();
                riepilogo.AppendLine($"Ordine per {tavolo}");
                riepilogo.AppendLine("================================");
                foreach (var ordine in Carrello)
                    riepilogo.AppendLine($"{ordine.Prodotto.Nome} x{ordine.Quantita} - {ordine.Totale:C}");
                riepilogo.AppendLine("================================");
                riepilogo.AppendLine($"Totale: {Carrello.Sum(o => o.Totale):C}");
                MessageBox.Show(riepilogo.ToString(), "Ordine Inviato");

                // Dopo l'invio, azzera le quantità selezionate per ogni prodotto e svuota il carrello.
                foreach (var prod in ProdottiMenu)
                    prod.QuantitaSelezionata = 0;
                Carrello.Clear();
                AggiornaTotale();
            }
            else
            {
                MessageBox.Show("Seleziona un tavolo valido.");
            }
        }

        // Questo metodo calcola e aggiorna il totale del carrello.
        private void AggiornaTotale()
        {
            // Somma il totale di ogni ordine nel carrello.
            decimal totale = Carrello.Sum(o => o.Totale);
            // Aggiorna il TextBlock "TxtTotale" con il totale formattato come valuta.
            TxtTotale.Text = $"Totale: {totale:C}";
        }
    }

    // ==========================================================
    // CLASSI DI SUPPORTO: Queste classi rappresentano le entità dell'applicazione.
    // ==========================================================

    // La classe Tavolo rappresenta un tavolo del ristorante.
    // Implementa INotifyPropertyChanged per aggiornare la UI quando lo stato del tavolo cambia (ad esempio, da libero a occupato).
    public class Tavolo : INotifyPropertyChanged
    {
        // La proprietà "NumeroTavolo" è in sola lettura e rappresenta il numero identificativo del tavolo.
        public int NumeroTavolo { get; }

        // Collezione degli ordini effettuati su questo tavolo.
        public ObservableCollection<Ordine> Ordini { get; }

        // Campo privato che memorizza lo stato "occupato" del tavolo.
        // Il nome del campo inizia con "_" per indicare che è privato.
        private bool _occupato;

        // Proprietà pubblica "Occupato" per accedere e modificare lo stato del tavolo.
        // Quando il valore cambia, viene chiamato OnPropertyChanged per notificare la UI.
        public bool Occupato
        {
            get => _occupato;
            set
            {
                if (_occupato != value)
                {
                    _occupato = value;
                    // Se il tavolo diventa libero, cancella tutti gli ordini.
                    if (!_occupato)
                        Ordini.Clear();
                    OnPropertyChanged(nameof(Occupato));
                }
            }
        }

        // Costruttore della classe Tavolo che accetta un numero come parametro.
        public Tavolo(int numero)
        {
            NumeroTavolo = numero;
            Ordini = new ObservableCollection<Ordine>();
            // Ogni volta che la collezione degli ordini cambia, aggiorna lo stato "Occupato".
            Ordini.CollectionChanged += (s, e) => Occupato = Ordini.Any();
        }

        // Override del metodo ToString per restituire una rappresentazione testuale del tavolo (es. "Tavolo 1").
        public override string ToString() => $"Tavolo {NumeroTavolo}";

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    // La classe Ordine rappresenta un singolo ordine effettuato su un tavolo.
    public class Ordine
    {
        // Nome del prodotto ordinato.
        public string Nome { get; set; }
        // Quantità ordinata.
        public int Quantità { get; set; }
        // Prezzo unitario del prodotto.
        // Utilizziamo il tipo "decimal" per la precisione nei valori monetari.
        public decimal Prezzo { get; set; }
    }

    // La classe ProdottoMenu rappresenta un prodotto presente nel menu.
    public class ProdottoMenu : INotifyPropertyChanged
    {
        // La proprietà "Id" identifica in modo univoco ogni prodotto (di tipo int).
        public int Id { get; set; }
        // Nome del prodotto.
        public string Nome { get; set; }
        // Categoria a cui appartiene il prodotto (ad es. "TAPAS", "TACOS", ecc.).
        public string Categoria { get; set; }
        // Prezzo unitario del prodotto. Il suffisso "m" indica un valore di tipo decimal.
        public decimal Prezzo { get; set; }

        // Campo privato per memorizzare la quantità selezionata dal cliente.
        // Il nome del campo inizia con "_" per indicare che è privato.
        private int _quantitaSelezionata;

        // Proprietà pubblica per accedere e modificare la quantità selezionata.
        public int QuantitaSelezionata
        {
            get => _quantitaSelezionata;
            set
            {
                if (_quantitaSelezionata != value)
                {
                    _quantitaSelezionata = value;
                    OnPropertyChanged(nameof(QuantitaSelezionata));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    // La classe OrdineCliente rappresenta un articolo nel carrello del cliente.
    // Calcola automaticamente il totale (Quantita * Prezzo) e notifica la UI in caso di variazioni.
    public class OrdineCliente : INotifyPropertyChanged
    {
        // Il prodotto ordinato.
        public ProdottoMenu Prodotto { get; set; }

        // Campo privato per la quantità ordinata.
        private int _quantita;

        // Proprietà "Quantita" per accedere e modificare la quantità ordinata.
        public int Quantita
        {
            get => _quantita;
            set
            {
                if (_quantita != value)
                {
                    _quantita = value;
                    OnPropertyChanged(nameof(Quantita));
                    // Poiché il totale dipende dalla quantità, notifica anche il cambiamento della proprietà "Totale".
                    OnPropertyChanged(nameof(Totale));
                }
            }
        }

        // Proprietà "Totale" calcolata come Quantita * Prezzo del prodotto.
        public decimal Totale => Quantita * Prodotto.Prezzo;

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
