﻿
namespace LA_PANINOTECA_D.L.F.M
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            panel1 = new Panel();
            textBox1 = new TextBox();
            button1 = new Button();
            Selezione = new CheckedListBox();
            etichettaCalorie = new Label();
            etichettaPrezzo = new Label();
            richTextBox1 = new RichTextBox();
            panel2 = new Panel();
            button6 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            pictureBox1 = new PictureBox();
            button5 = new Button();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel1.BackColor = Color.Coral;
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(button1);
            panel1.Location = new Point(1, 1);
            panel1.Name = "panel1";
            panel1.Size = new Size(1553, 46);
            panel1.TabIndex = 0;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.Coral;
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Font = new Font("Times New Roman", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(46, 9);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(111, 34);
            textBox1.TabIndex = 1;
            textBox1.Text = "MENU";
            // 
            // button1
            // 
            button1.BackColor = Color.Coral;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(11, 0);
            button1.Name = "button1";
            button1.Size = new Size(38, 43);
            button1.TabIndex = 0;
            button1.Text = "☰";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Selezione
            // 
            Selezione.BackColor = Color.Tan;
            Selezione.BorderStyle = BorderStyle.None;
            Selezione.Font = new Font("Poor Richard", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Selezione.FormattingEnabled = true;
            Selezione.Location = new Point(1042, 117);
            Selezione.Name = "Selezione";
            Selezione.Size = new Size(195, 364);
            Selezione.TabIndex = 1;
            Selezione.SelectedIndexChanged += checkedListBox1_SelectedIndexChanged;
            // 
            // etichettaCalorie
            // 
            etichettaCalorie.AutoSize = true;
            etichettaCalorie.Font = new Font("Segoe UI", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            etichettaCalorie.Location = new Point(1265, 117);
            etichettaCalorie.Name = "etichettaCalorie";
            etichettaCalorie.Size = new Size(36, 47);
            etichettaCalorie.TabIndex = 2;
            etichettaCalorie.Text = "..";
            // 
            // etichettaPrezzo
            // 
            etichettaPrezzo.AutoSize = true;
            etichettaPrezzo.Font = new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            etichettaPrezzo.Location = new Point(1265, 179);
            etichettaPrezzo.Name = "etichettaPrezzo";
            etichettaPrezzo.Size = new Size(56, 47);
            etichettaPrezzo.TabIndex = 3;
            etichettaPrezzo.Text = "....";
            // 
            // richTextBox1
            // 
            richTextBox1.BackColor = Color.Tan;
            richTextBox1.BorderStyle = BorderStyle.None;
            richTextBox1.Font = new Font("Microsoft JhengHei", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            richTextBox1.Location = new Point(47, 83);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(959, 674);
            richTextBox1.TabIndex = 4;
            richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // panel2
            // 
            panel2.BackColor = Color.Coral;
            panel2.Controls.Add(button6);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(button2);
            panel2.Location = new Point(1, 44);
            panel2.Name = "panel2";
            panel2.Size = new Size(224, 758);
            panel2.TabIndex = 5;
            // 
            // button6
            // 
            button6.BackColor = Color.Black;
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Lucida Calligraphy", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button6.ForeColor = Color.Gold;
            button6.Location = new Point(0, 696);
            button6.Name = "button6";
            button6.RightToLeft = RightToLeft.No;
            button6.Size = new Size(223, 51);
            button6.TabIndex = 4;
            button6.Text = "🏡 HOME";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.Red;
            button4.BackgroundImageLayout = ImageLayout.None;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Ravie", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.Black;
            button4.Location = new Point(0, 544);
            button4.Name = "button4";
            button4.Size = new Size(224, 80);
            button4.TabIndex = 2;
            button4.Text = "A SCELTA";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.DarkSalmon;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Bauhaus 93", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(0, 293);
            button3.Name = "button3";
            button3.Size = new Size(224, 80);
            button3.TabIndex = 1;
            button3.Text = "DAIANA BURGER ";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.DarkSalmon;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Algerian", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(0, 73);
            button2.Name = "button2";
            button2.Size = new Size(223, 80);
            button2.TabIndex = 0;
            button2.Text = "PANINO NAPOLI";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.Location = new Point(514, 252);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(375, 229);
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // button5
            // 
            button5.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            button5.FlatAppearance.BorderSize = 10;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Reem Kufi", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.FromArgb(0, 0, 192);
            button5.Location = new Point(922, 688);
            button5.Name = "button5";
            button5.Size = new Size(440, 79);
            button5.TabIndex = 11;
            button5.Text = "AGGIUNGI ALL'ORDINE";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // Form5
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Tan;
            ClientSize = new Size(1553, 803);
            Controls.Add(button5);
            Controls.Add(pictureBox1);
            Controls.Add(panel2);
            Controls.Add(richTextBox1);
            Controls.Add(etichettaPrezzo);
            Controls.Add(etichettaCalorie);
            Controls.Add(Selezione);
            Controls.Add(panel1);
            Name = "Form5";
            Text = "Form5";
            Load += Form5_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            AggiornaCalorie(sender, e);
        }


        #endregion

        private Button button1;
        private Panel panel1;
        private TextBox textBox1;
        private CheckedListBox Selezione;
        private Label etichettaCalorie;
        private Label etichettaPrezzo;
        private RichTextBox richTextBox1;
        private Panel panel2;
        private Button button3;
        private Button button2;
        private Button button4;
        private PictureBox pictureBox1;
        private Button button5;
        private Button button6;
    }
}