﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LA_PANINOTECA_D.L.F.M
{
    public partial class Form5 : Form
    {
        private Dictionary<string, int> dizionarioCalorie; // Dizionario per le calorie degli ingredienti

        public Form5()
        {
            InitializeComponent();
            panel2.Visible = false;

            // Inizializza il dizionario delle calorie
            dizionarioCalorie = new Dictionary<string, int>
            {
                { "Mais", 365 },
                { "Pomodori", 19 },
                { "Insalata", 22 },
                { "cheddar", 388 },
                { "salsa ketchup", 100 },
                { "salsa Maionese", 660 },
                { "salsa rissa", 368 }
            };
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            // Aggiungi gli ingredienti alla CheckedListBox
            Selezione.Items.Add("Mais");
            Selezione.Items.Add("Pomodori");
            Selezione.Items.Add("Insalata");
            Selezione.Items.Add("cheddar");
            Selezione.Items.Add("salsa ketchup");
            Selezione.Items.Add("salsa Maionese");
            Selezione.Items.Add("salsa rissa");

            // Imposta l'evento per aggiornare le calorie
            Selezione.SelectedIndexChanged += AggiornaCalorie;
        }

        private void AggiornaCalorie(object sender, EventArgs e)
        {
            int calorieTotali = 605; // Calorie di base del panino
            int prezzoTotale = 4; // Prezzo base del panino

            // Aggiungi calorie e prezzo per ogni ingrediente selezionato
            foreach (var item in Selezione.CheckedItems)
            {
                string ingredienteSelezionato = item.ToString();
                if (dizionarioCalorie.ContainsKey(ingredienteSelezionato))
                {
                    calorieTotali += dizionarioCalorie[ingredienteSelezionato];
                    prezzoTotale += 1; // Aggiungi 1€ per ogni ingrediente
                }
            }

            // Visualizza il totale delle calorie e del prezzo
            etichettaCalorie.Text = $"Calorie: {calorieTotali}";
            etichettaPrezzo.Text = $"Prezzo: {prezzoTotale}€";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel2.Visible = !panel2.Visible; // Mostra o nascondi il pannello
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Show();
            this.Hide();
            Form3 form3 = new Form3(); // Crea una nuova istanza di Form3
            form3.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Show();
            this.Hide();
            Form4 form4 = new Form4(); // Crea una nuova istanza di Form4
            form4.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Inizializza il totale delle calorie e del prezzo
            int caloriePanino = 605;  // Calorie di base del panino
            decimal prezzoPanino = 4m;  // Prezzo di base del panino

            // Aggiungi le calorie e il prezzo degli ingredienti selezionati
            foreach (var item in Selezione.CheckedItems)
            {
                string ingrediente = item.ToString();
                if (dizionarioCalorie.ContainsKey(ingrediente))
                {
                    caloriePanino += dizionarioCalorie[ingrediente];  // Aggiungi le calorie dell'ingrediente
                    prezzoPanino += 1m;  // Aggiungi 1€ per ogni ingrediente selezionato
                }
            }

            // Mostra il messaggio con il totale delle calorie e del prezzo 
            Ordine.Aggiungi(caloriePanino, prezzoPanino);
            MessageBox.Show($"Panino aggiunto! Totale attuale: {Ordine.TotaleCalorie} calorie,{Ordine.TotalePrezzo:C}");
            //button5.Text = Ordine.TotalePrezzo.ToString();




        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Show();
            this.Hide();
            Form2 form2 = new Form2(); // Crea una nuova istanza di Form4
            form2.Show();
        }
    }
}