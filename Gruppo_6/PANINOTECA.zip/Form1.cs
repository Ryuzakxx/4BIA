namespace LA_PANINOTECA_D.L.F.M
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 newForm = new Form2();

            // Mostriamo il nuovo form
            newForm.Show();

            // Nascondiamo il form attuale, se necessario
            this.Hide();

        }
    }
}
