﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LA_PANINOTECA_D.L.F.M
{
    public static class Ordine
    {
        public static int TotaleCalorie { get; private set; } = 0;    
        public static decimal TotalePrezzo { get; private set; } = 0;
    
        public static void Aggiungi(int calorie,decimal prezzo)
            {
                TotaleCalorie+=calorie;
                TotalePrezzo+=prezzo;

            } 
        public static void Reset()
            {
                TotaleCalorie = 0; 
                TotalePrezzo = 0;
            }
    }
}
