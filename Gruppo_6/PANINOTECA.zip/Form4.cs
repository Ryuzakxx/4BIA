﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace LA_PANINOTECA_D.L.F.M
{
    public partial class Form4 : Form
    {
        private Form2 _form2; //riferimento al form 
        public Form4(Form2 form2) //costruttore che riceve form 
        {
            InitializeComponent();

            panel2.Visible = false;
        }

        public Form4()
        {
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel2.Visible = !panel2.Visible;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Show();
            this.Hide();
            Form3 form3 = new Form3(); // Crea una nuova istanza di Form3
            form3.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();  // Mostra il Form5
            this.Hide();   // Nasconde Form4
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int caloriePanino = 310; //calorie panino napoli
            decimal prezzoPanino = 6.80m;
            Ordine.Aggiungi(caloriePanino, prezzoPanino);
            MessageBox.Show($"Panino aggiunto! Totale attuale: {Ordine.TotaleCalorie} calorie,{Ordine.TotalePrezzo:C}");            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Show();
            this.Hide();
            Form2 form2 = new Form2(); // Crea una nuova istanza di Form4
            form2.Show();
        }
    }
}
